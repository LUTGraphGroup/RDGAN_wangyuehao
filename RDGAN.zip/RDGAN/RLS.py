import numpy as np
import pandas as pd

# Levenshtein_Distance
# 已修改 插入和删除的编辑成本均为1，替换的编辑成本为2


'''
也可以直接调用库，所有成本均为1
import Levenshtein
print(Levenshtein.distance('abc', 'aecfaf'))
'''

# 递归调用
def Levenshtein_Distance_Recursive(str1, str2):
    '''
    递归调用栈深度超过1000出错，和这个一起用
    import sys  # 导入sys模块
    sys.setrecursionlimit(3000)  # 将默认的递归深度修改为3000
    '''
    if len(str1) == 0:
        return len(str2)
    elif len(str2) == 0:
        return len(str1)
    elif str1 == str2:
        return 0

    if str1[len(str1) - 1] == str2[len(str2) - 1]:
        d = 0
    else:
        d = 2

    return min(Levenshtein_Distance_Recursive(str1, str2[:-1]) + 1,
               Levenshtein_Distance_Recursive(str1[:-1], str2) + 1,
               Levenshtein_Distance_Recursive(str1[:-1], str2[:-1]) +d)

#动态规划
def normal_leven(str1, str2):
    len_str1 = len(str1) + 1
    len_str2 = len(str2) + 1
    # 创建矩阵
    matrix = [0 for n in range(len_str1 * len_str2)]
    # 矩阵的第一行
    for i in range(len_str1):
        matrix[i] = i
    # 矩阵的第一列
    for j in range(0, len(matrix), len_str1):
        if j % len_str1 == 0:
            matrix[j] = j // len_str1
    # 根据状态转移方程逐步得到编辑距离
    for i in range(1, len_str1):
        for j in range(1, len_str2):
            if str1[i - 1] == str2[j - 1]:
                cost = 0
            else:
                cost = 2
            matrix[j * len_str1 + i] = min(matrix[(j - 1) * len_str1 + i] + 1,
                                           matrix[j * len_str1 + (i - 1)] + 1,
                                           matrix[(j - 1) * len_str1 + (i - 1)] + cost)

    return matrix[-1]  # 返回矩阵的最后一个值，也就是编辑距离



a = pd.read_excel('circRNAName.xlsx', header=0,keep_default_na=False)
#在使用 pandas.read_excel(file)这个方法时可以在后面加上keep_default_na=False，这样读取到空字符串时读出的就是''而不是nan了：
RNA = a['circRNA_Name'].tolist()
seq = a['sequence'].tolist()
print('RNA数量',len(RNA))
# print('RNA',RNA)
print(len(seq))
# print('sequence',seq)
count=0
kong=0
for i in range(len(seq)):
    if seq[i]=='':
        kong=kong+1
    else:
        count=count+1
print('能找到序列的RNA个数：',count,'未找到序列RNA个数：',kong)


RLS = np.zeros([len(RNA), len(RNA)])

#计算相似性
jj = 0  # RLS是对称矩阵，用jj来减少运算量
for i in range(len(RNA)):
        for j in range(jj,len(RNA)):
            if i==j:
                RLS[i, i] =1  #对角线为1
                print('第', i + 1, '个RNA和第', j + 1, '个RNA , ', '他们各自长度：', len(seq[i]),',', len(seq[j]), '  lev距离：',
                      0,'  相似性：',RLS[i, j])
            elif seq[i]=='' or seq[j]=='':
                RLS[i,j]=RLS[j,i]=0  #RNA没有序列号 相似性为0
                dist=normal_leven(seq[i], seq[j])
                print('第', i + 1, '个RNA和第', j + 1, '个RNA , ', '他们各自长度：', len(seq[i]),',', len(seq[j]), '  lev距离：',
                      dist,'  相似性：',RLS[i, j])
            else:
                dist=normal_leven(seq[i], seq[j])
                RLS[i,j]=RLS[j,i]=round(1-dist/(len(seq[i])+len(seq[j])),5) #计算相似性,round()函数 保留小数点后5位
                print('第', i + 1, '个RNA和第', j + 1, '个RNA , ', '他们各自长度：', len(seq[i]),',', len(seq[j]), '  lev距离：',
                      dist,'  相似性：',RLS[i, j])
        jj = jj + 1
'''
#部分RNA没有查到序列号，循环中会赋值0，对角线可能不为1
#将矩阵对角线赋值1
row, col = np.diag_indices_from(RLS)
RLS[row,col] = 1
'''
print('rna相似性矩阵形状',RLS.shape)

np.save('RLS.npy',RLS)
result = pd.DataFrame(RLS)
result.to_excel('./data/RLS.xlsx',header=0,index=0)




