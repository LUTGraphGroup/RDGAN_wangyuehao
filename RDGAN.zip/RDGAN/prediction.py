import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch_geometric.data import Data, DataLoader
from torch_geometric.nn import GCNConv

import pandas as pd

#读取数据
feature_matrix = pd.read_csv('input_matrix.csv',header=None)
association_matrix = pd.read_excel('associationMatrix.xlsx',header=None)
association_matrix = torch.from_numpy(association_matrix).float()
#保留20%的测试数据
association_matrix2 = association_matrix.copy()
indices = np.where(association_matrix == 1)
for i in range(0,130):
    association_matrix2[indices[0][i],indices[1][i]]=0
association_matrix = association_matrix2

feature_matrix = torch.from_numpy(feature_matrix).float()
rna_features = feature_matrix[:599]
disease_features = feature_matrix[599:]

#定义图卷积网络
class GNN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GNN, self).__init__()
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, output_dim)

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = torch.relu(x)
        x = self.conv2(x, edge_index)
        return x

#网络参数
input_dim = feature_matrix.shape[1]
hidden_dim = 128
output_dim = 1

#从数据中建立图
rna_nodes = np.arange(599)
disease_nodes = np.arange(599,86)
edge_index = np.transpose(np.array(np.meshgrid(rna_nodes, disease_nodes)), (1, 2, 0)).reshape(-1, 2).T
x = torch.cat([rna_features, disease_features], dim=0)
edge_index = torch.from_numpy(edge_index)
data = Data(x=x, edge_index=edge_index)

model = GNN(input_dim, hidden_dim, output_dim)

#其他参数
loss_fn = nn.BCEWithLogitsLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
batch_size = 32
dataset = DataLoader([data], batch_size=batch_size, shuffle=True)

#训练循环
num_epochs = 100

for epoch in range(num_epochs):
    running_loss = 0.0
    for batch_data in dataset:
        optimizer.zero_grad()
        outputs = model(batch_data.x, batch_data.edge_index)
        batch_labels = association_matrix.view(-1, 1)
        loss = loss_fn(outputs, batch_labels)

        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    average_loss = running_loss / len(dataset)
    print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {average_loss}")

model.eval()
with torch.no_grad():
    test_outputs = model(data.x, data.edge_index)
    predictions = torch.sigmoid(test_outputs)

association_predictions = (predictions > 0.5).int().numpy()
print(association_predictions)