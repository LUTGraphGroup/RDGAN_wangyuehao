import pandas as pd
import numpy as np
import networkx as nx 

#读取文件
asso_matrix = pd.read_excel('associationMatrix.xlsx',header=None)
dms = pd.read_excel('DMS.xlsx',header=None)
disease_GaussianSimilarity = pd.read_excel('disease_GaussianSimilarity.xlsx',header=None)
rls = pd.read_excel('RLS.xlsx',header=None)
rna_GaussianSimilarity = pd.read_excel('rna_GaussianSimilarity.xlsx',header=None)

#mat1：待补全的矩阵,mat2：用于补全mat1的矩阵
def fill_matrix(mat1,mat2):
    rows = mat1.shape[0]
    cols = mat1.shape[1]
    #复制一份防止修改原文件
    mat1_copy = mat1.copy()
    for i in range(rows):
        for j in range(cols):
            if mat1[i][j] == 0.0:
                mat1_copy[i][j] = mat2[i][j]
    return mat1_copy

dms_completed = fill_matrix(dms,disease_GaussianSimilarity)
rls_completed = fill_matrix(rls,rna_GaussianSimilarity)

#将四个矩阵拼接
def stack_matrix(mat1,mat2,mat3):
    top_row = np.hstack((mat1, mat3))
    bottom_row = np.hstack((mat3.T, mat2))
    matrix = np.vstack((top_row, bottom_row))
    return matrix
#input_matrix = stack_matrix(rls_completed.values,dms_completed.values,asso_matrix.values)

#根据相似度矩阵计算电阻距离矩阵
#dms >0 ,rls>0
#print(np.sum(rls.values.flatten()>0.1))
def rd(matrix,thred=0.0): 
    #根据阈值确定边
    elist=[]
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            print(i,j)
            if (i < j) & (matrix.values[i][j] > thred):
                elist.append((i,j))
    #建立图
    G = nx.Graph()
    G.add_edges_from(elist)
    #计算电阻距离矩阵
    resistancematrix = np.zeros(shape=(matrix.shape))
    
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            #print(i,j)
            if i == j:
                resistancematrix[i][j]= 0
                
            elif i < j:
                #如果两个节点联通
                if (i,j) in elist:
                    resistancematrix[i][j]=nx.resistance_distance(G, i, j, weight=None)
                    resistancematrix[j][i]=resistancematrix[i][j]
                else:
                    resistancematrix[i][j] = 0
                    resistancematrix[j][i] = 0
                    
                
    return resistancematrix

dms_rd = rd(dms)
result = np.concatenate((dms, dms_rd), axis=1)
result = pd.DataFrame(result)
result.to_excel('dms_rd.xlsx',header=0,index=0)

rls_rd = rd(rls)
result = np.concatenate((rls, rls_rd), axis=1)
result = pd.DataFrame(result)
result.to_excel('rls_rd.xlsx',header=0,index=0)